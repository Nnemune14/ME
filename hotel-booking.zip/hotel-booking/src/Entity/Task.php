<?php
// src/Entity/Task.php
namespace App\Entity;

use Doctrine\Common\Collections\Selectable;

class Task
{
    protected $candidateName;

    protected $candidateSurname;

    protected $candidateEmail;

    protected $candidateFavoriteFoood;

    protected $dueDate;

    protected $task;

    protected $string;

    protected $candidateGender;

    public function getCandidateName()
    {
        return $this->candidateName;
    }

    public function setCandidateName(string $task)
    {
        return $this->candidateName = $task;
    }

    public function setCandidateSurname($task)
    {
        $this->task = $task;
    }

    public function getCandidateSurname()
    {
        return $this->task;
    }
    public function setCandidateEmail(string $string)
    {
        $this->string = $string;
    }
    public function getCandidateEmail()
    {
        return $this->candidateEmail;
    }
    public function setCandidateGender(string $string)
    {
        $this->string = $string;
    }
    public function getCandidateGender()
    {
        return $this->candidateGender;
    }
    public function setCandidateGender1(string $string)
    {
        $this->string = $string;
    }
    public function getCandidateGender1()
    {
        return $this->candidateGender;
    }
    public function setCandidateFavoriteFoood(string $string)
    {
        $this->string = $string;
    }

    public function getCandidateFavoriteFoood()
    {
        return $this->candidateFavoriteFoood;
    }

//    public function getCandidateFavFood()
//    {
//        return $this->candidateFavFood;
//    }
//
//    public function setCandidateFavFood(string $string)
//    {
//        $this->string = $string;
//    }




}
