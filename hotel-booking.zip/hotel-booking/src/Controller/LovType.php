<?php


namespace App\Controller;


class LovType
{

}