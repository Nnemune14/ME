<?php
// src/Controller/TaskController.php
namespace App\Controller;

use Symfony\Component\Form\Extension\Core\Type\ChoiceType;
use Symfony\Component\Form\Extension\Core\Type\EmailType;
use Symfony\Component\Form\Extension\Core\Type\RadioType;
use Symfony\Component\Routing\Annotation\Route;
use App\Form\Type\TaskType;
use App\Entity\Task;
use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;
use Symfony\Component\HttpFoundation\Request;
use MiWay\Bundle\CoreBundle\Form\Type\LovType;

class TaskController extends AbstractController
{
    /**
     * @Route("/lucky/number")
     */

    public function new(Request $request)
    {
        // creates a task object and initializes some data for this example
        $task = new Task();
        $task->setCandidateName('');
        $task->setCandidateSurname('');
        $task->setCandidateEmail('');
        $task->setCandidateGender(RadioType::class);
        $task->setCandidateGender1(RadioType::class);
        $task->setCandidateFavoriteFoood(ChoiceType::class);


        $form = $this->createForm(TaskType::class, $task);

        return $this->render('task/new.html.twig', [
            'form' => $form->createView(),
        ]);

    }
}
