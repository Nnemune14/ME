<?php


namespace App\Controller;

use Symfony\Component\Routing\Annotation\Route;
use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;
use Symfony\Component\HttpFoundation\Response;

class HomeController extends AbstractController
{
    /**
     * @Route("/home")
     */
    public function menu() {

        return $this->render('blog/home.html.twig');


    }
    public function inIt() {
        return $this->render('blog/home.html.twig');
    }
}