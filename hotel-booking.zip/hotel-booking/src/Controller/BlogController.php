<?php


namespace App\Controller;


use Sensio\Bundle\FrameworkExtraBundle\Configuration\Route;
use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;

class BlogController extends AbstractController
{

    /**
     * @Route("/blog")
     * @return \Symfony\Component\HttpFoundation\Response
     */
    public function blog()
    {
        return $this->render('blog/index.html.twig',[
            'blog_entries' => []
        ]);
    }
}

