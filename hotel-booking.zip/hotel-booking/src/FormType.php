<?php


namespace App;


class FormType
{
    public function buildFormAction(FormBuilderInterface $builder, array $options){
        $builder->add(
            'candidate_challenge',
            ButtonType::class,
            [
                'label' => 'Candidate Challenge',
            ]
        );
    }
}