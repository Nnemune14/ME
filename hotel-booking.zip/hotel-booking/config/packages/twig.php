<?php
// config/packages/twig.php
$container->loadFromExtension('twig', [
    'form_themes' => [
        'bootstrap_4_layout.html.twig',
    ],

    // ...
]);