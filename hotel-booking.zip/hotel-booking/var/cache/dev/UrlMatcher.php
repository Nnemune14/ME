<?php

/**
 * This file has been auto-generated
 * by the Symfony Routing Component.
 */

return [
    false, // $matchHost
    [ // $staticRoutes
        '/blog' => [
            [['_route' => 'app_blog_blog', '_controller' => 'App\\Controller\\BlogController::blog'], null, null, null, false, false, null],
            [['_route' => 'app_blog', '_controller' => 'App\\Controller\\BlogController::blog'], null, null, null, false, false, null],
        ],
        '/home' => [
            [['_route' => 'app_home_menu', '_controller' => 'App\\Controller\\HomeController::menu'], null, null, null, false, false, null],
            [['_route' => 'app_menu', '_controller' => 'App\\Controller\\HomeController::menu'], null, null, null, false, false, null],
            [['_route' => 'app_init', '_controller' => 'App\\Controller\\HomeController::inIt'], null, null, null, false, false, null],
        ],
        '/lucky/number' => [
            [['_route' => 'app_task_new', '_controller' => 'App\\Controller\\TaskController::new'], null, null, null, false, false, null],
            [['_route' => 'app_lucky_number', '_controller' => 'App\\Controller\\LuckyController::number'], null, null, null, false, false, null],
            [['_route' => 'app_candidate_challenge', '_controller' => 'App\\Controller\\TaskController::new'], null, null, null, false, false, null],
        ],
    ],
    [ // $regexpList
        0 => '{^(?'
                .'|/_error/(\\d+)(?:\\.([^/]++))?(*:35)'
            .')/?$}sDu',
    ],
    [ // $dynamicRoutes
        35 => [
            [['_route' => '_twig_error_test', '_controller' => 'twig.controller.preview_error::previewErrorPageAction', '_format' => 'html'], ['code', '_format'], null, null, false, true, null],
            [null, null, null, null, false, false, 0],
        ],
    ],
    null, // $checkCondition
];
