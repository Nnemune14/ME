<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* task/new.html.twig */
class __TwigTemplate_ead194d84dc9ae500804b8e6dc69470733a7145522f4d343a74729f1132b7916 extends \Twig\Template
{
    private $source;
    private $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = [
            'javascripts' => [$this, 'block_javascripts'],
            'navbar' => [$this, 'block_navbar'],
            'body' => [$this, 'block_body'],
        ];
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "template", "task/new.html.twig"));

        // line 2
        echo "<link rel=\"stylesheet\" href=\"https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css\" integrity=\"sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T\" crossorigin=\"anonymous\">

<html>
<title> HELLO </title>
<body>



";
        // line 10
        $this->displayBlock('javascripts', $context, $blocks);
        // line 13
        echo "
";
        // line 16
        echo "<style type=\"text/css\">

    #float{
        float: left;
        background-color: #AA3333;
    }
    .container-fluid {
        alignment: right;
        margin-left: 0px;
    }
    #content-all {
        margin-left: 0px;
        background-color: #CE5B78;
    }


</style>

    ";
        // line 34
        $this->displayBlock('navbar', $context, $blocks);
        // line 42
        echo "</div>

<div id=\"content-all\">
    ";
        // line 45
        $this->displayBlock('body', $context, $blocks);
        // line 55
        echo "</div>

</body>
</html>


";
        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

    }

    // line 10
    public function block_javascripts($context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "javascripts"));

        // line 11
        echo "<div id=\"collapse navbar-collapse\">
    ";
        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

    }

    // line 34
    public function block_navbar($context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "navbar"));

        // line 35
        echo "        <div id=\"float\" class=\"container-fluid\">
            <ul class=\"nav \">
                <li><a href=\"/\" class=\"badge badge-primary\">Home</a></li>
                <li><a href=\"/blog\" class=\"badge badge-success\">Blog1</a></li>
            </ul>
        </div>
    ";
        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

    }

    // line 45
    public function block_body($context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "body"));

        // line 46
        echo "        <div id=\"content\">
            <h2><u>My first post</u></h2>
            <p>The body of the first post.</p>

            <h2><u>Another post</u></h2>
            <p>The body of the second post.</p>
        </div>
        ";
        // line 53
        echo         $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->renderBlock((isset($context["form"]) || array_key_exists("form", $context) ? $context["form"] : (function () { throw new RuntimeError('Variable "form" does not exist.', 53, $this->source); })()), 'form');
        echo "
    ";
        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

    }

    public function getTemplateName()
    {
        return "task/new.html.twig";
    }

    public function getDebugInfo()
    {
        return array (  151 => 53,  142 => 46,  135 => 45,  122 => 35,  115 => 34,  107 => 11,  100 => 10,  87 => 55,  85 => 45,  80 => 42,  78 => 34,  58 => 16,  55 => 13,  53 => 10,  43 => 2,);
    }

    public function getSourceContext()
    {
        return new Source("{# templates/task/new.html.twig #}
<link rel=\"stylesheet\" href=\"https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css\" integrity=\"sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T\" crossorigin=\"anonymous\">

<html>
<title> HELLO </title>
<body>



{% block javascripts %}
<div id=\"collapse navbar-collapse\">
    {% endblock %}

{#        <script src=\"https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js\"></script>#}
{#        <script src=\"https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/js/bootstrap.min.js\"></script>#}
<style type=\"text/css\">

    #float{
        float: left;
        background-color: #AA3333;
    }
    .container-fluid {
        alignment: right;
        margin-left: 0px;
    }
    #content-all {
        margin-left: 0px;
        background-color: #CE5B78;
    }


</style>

    {% block navbar %}
        <div id=\"float\" class=\"container-fluid\">
            <ul class=\"nav \">
                <li><a href=\"/\" class=\"badge badge-primary\">Home</a></li>
                <li><a href=\"/blog\" class=\"badge badge-success\">Blog1</a></li>
            </ul>
        </div>
    {% endblock %}
</div>

<div id=\"content-all\">
    {% block body %}
        <div id=\"content\">
            <h2><u>My first post</u></h2>
            <p>The body of the first post.</p>

            <h2><u>Another post</u></h2>
            <p>The body of the second post.</p>
        </div>
        {{ form(form) }}
    {% endblock %}
</div>

</body>
</html>


", "task/new.html.twig", "/home/emmanuelma/htdocs/hotel-booking/templates/task/new.html.twig");
    }
}
