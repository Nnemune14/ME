<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* base.html.twig */
class __TwigTemplate_4d2b4f9bc39dbf2fcf2dde41221df112aff6162689aac935c3cc768e387bca93 extends \Twig\Template
{
    private $source;
    private $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = [
            'title' => [$this, 'block_title'],
            'stylesheets' => [$this, 'block_stylesheets'],
            'javascripts' => [$this, 'block_javascripts'],
            'sidebar' => [$this, 'block_sidebar'],
            'body' => [$this, 'block_body'],
            'script' => [$this, 'block_script'],
        ];
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "template", "base.html.twig"));

        // line 1
        echo "<!DOCTYPE html>


<link rel=\"stylesheet\" href=\"https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css\" integrity=\"sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T\" crossorigin=\"anonymous\">
<script src=\"https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js\"></script>
<script src=\"https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/js/bootstrap.min.js\"></script>

<style type=\"text/css\">
    #float{
        float: left;
        background-color: #AA3333;
    }
    .nav {
        padding-left: 10px;
        margin: 5px;
        position: relative;
        left:10px;
        font-size: 20px;

    }
</style>

<html lang=\"en\"> <script src=\"https://kit.fontawesome.com/bfe291f773.js\" crossorigin=\"anonymous\"></script>
    <head>
        <meta charset=\"UTF-8\">
        <title>";
        // line 26
        $this->displayBlock('title', $context, $blocks);
        echo "</title>
        ";
        // line 27
        $this->displayBlock('stylesheets', $context, $blocks);
        // line 30
        echo "    </head>
    <body>
        ";
        // line 32
        $this->displayBlock('javascripts', $context, $blocks);
        // line 35
        echo "        ";
        $this->displayBlock('sidebar', $context, $blocks);
        // line 65
        echo "        </div>

        <div id=\"content\">
            ";
        // line 68
        $this->displayBlock('body', $context, $blocks);
        // line 69
        echo "        </div>

        ";
        // line 71
        $this->displayBlock('script', $context, $blocks);
        // line 74
        echo "    </body>
</html>

</div>";
        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

    }

    // line 26
    public function block_title($context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "title"));

        echo "Welcome!";
        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

    }

    // line 27
    public function block_stylesheets($context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "stylesheets"));

        // line 28
        echo "            <link href=\"";
        echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("css/main.css"), "html", null, true);
        echo "\" rel=\"stylesheet\"/>
        ";
        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

    }

    // line 32
    public function block_javascripts($context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "javascripts"));

        // line 33
        echo "
        <div id=\"sidebar\" class=\"fa-1x\"> ";
        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

    }

    // line 35
    public function block_sidebar($context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "sidebar"));

        // line 36
        echo "            <div id=\"float\" class=\"container-fluid\">
                <div class=\"alert alert-primary\" role=\"alert\">
                </div>

                <ul class=\"nav\">
                    <li><a href=\"/\" class=\"badge badge-primary\" >Home</a></li>
                    <li><a href=\"/blog\" class=\"badge badge-warning\" >Blog</a></li>
                    <li><a href=\"/home\" class=\"badge badge-success\">Menu</a></li>
                    <li><i class=\"fas fa-camera fa-x10\"></i></li>

                </ul>
                <div><i class=\"fas fa-snowplow fa-fw\" style=\"background:DodgerBlue\"></i> Snowplow</div>
                <ul class=\"fa-ul\">
                    <li><span class=\"fa-li\"><i class=\"fas fa-spinner fa-pulse\"></i></span>replace bullets</li>
                </ul>
                <i class=\"fas fa-quote-left fa-2x fa-pull-left\"></i>Gatsby believed in the green light, the orgastic future that year by year recedes before us.
                It eluded us then, but that’s no matter — tomorrow we will run faster, stretch our arms further...
                And one fine morning — So we beat on, boats against the current, borne back ceaselessly into the past.
                <span class=\"fa-stack fa-2x\">
                <i class=\"fas fa-circle fa-stack-2x\"></i>
                 <i class=\"fab fa-twitter fa-stack-1x fa-inverse\"></i>
                </span>

                <span class=\"fa-layers fa-fw\" style=\"background:MistyRose\">
                    <i class=\"fas fa-envelope\"></i>
                    <span class=\"fa-layers-counter\" style=\"background:Tomato\">1,419</span>
                </span>
            </div>
        ";
        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

    }

    // line 68
    public function block_body($context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "body"));

        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

    }

    // line 71
    public function block_script($context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "script"));

        // line 72
        echo "            <script src=\"";
        echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("js/main.js"), "html", null, true);
        echo "\"></script>
        ";
        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

    }

    public function getTemplateName()
    {
        return "base.html.twig";
    }

    public function getDebugInfo()
    {
        return array (  217 => 72,  210 => 71,  198 => 68,  163 => 36,  156 => 35,  148 => 33,  141 => 32,  131 => 28,  124 => 27,  111 => 26,  101 => 74,  99 => 71,  95 => 69,  93 => 68,  88 => 65,  85 => 35,  83 => 32,  79 => 30,  77 => 27,  73 => 26,  46 => 1,);
    }

    public function getSourceContext()
    {
        return new Source("<!DOCTYPE html>


<link rel=\"stylesheet\" href=\"https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css\" integrity=\"sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T\" crossorigin=\"anonymous\">
<script src=\"https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js\"></script>
<script src=\"https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/js/bootstrap.min.js\"></script>

<style type=\"text/css\">
    #float{
        float: left;
        background-color: #AA3333;
    }
    .nav {
        padding-left: 10px;
        margin: 5px;
        position: relative;
        left:10px;
        font-size: 20px;

    }
</style>

<html lang=\"en\"> <script src=\"https://kit.fontawesome.com/bfe291f773.js\" crossorigin=\"anonymous\"></script>
    <head>
        <meta charset=\"UTF-8\">
        <title>{% block title %}Welcome!{% endblock %}</title>
        {% block stylesheets %}
            <link href=\"{{ asset('css/main.css') }}\" rel=\"stylesheet\"/>
        {% endblock %}
    </head>
    <body>
        {% block javascripts %}

        <div id=\"sidebar\" class=\"fa-1x\"> {% endblock %}
        {% block sidebar %}
            <div id=\"float\" class=\"container-fluid\">
                <div class=\"alert alert-primary\" role=\"alert\">
                </div>

                <ul class=\"nav\">
                    <li><a href=\"/\" class=\"badge badge-primary\" >Home</a></li>
                    <li><a href=\"/blog\" class=\"badge badge-warning\" >Blog</a></li>
                    <li><a href=\"/home\" class=\"badge badge-success\">Menu</a></li>
                    <li><i class=\"fas fa-camera fa-x10\"></i></li>

                </ul>
                <div><i class=\"fas fa-snowplow fa-fw\" style=\"background:DodgerBlue\"></i> Snowplow</div>
                <ul class=\"fa-ul\">
                    <li><span class=\"fa-li\"><i class=\"fas fa-spinner fa-pulse\"></i></span>replace bullets</li>
                </ul>
                <i class=\"fas fa-quote-left fa-2x fa-pull-left\"></i>Gatsby believed in the green light, the orgastic future that year by year recedes before us.
                It eluded us then, but that’s no matter — tomorrow we will run faster, stretch our arms further...
                And one fine morning — So we beat on, boats against the current, borne back ceaselessly into the past.
                <span class=\"fa-stack fa-2x\">
                <i class=\"fas fa-circle fa-stack-2x\"></i>
                 <i class=\"fab fa-twitter fa-stack-1x fa-inverse\"></i>
                </span>

                <span class=\"fa-layers fa-fw\" style=\"background:MistyRose\">
                    <i class=\"fas fa-envelope\"></i>
                    <span class=\"fa-layers-counter\" style=\"background:Tomato\">1,419</span>
                </span>
            </div>
        {% endblock %}
        </div>

        <div id=\"content\">
            {% block body %}{% endblock %}
        </div>

        {% block script %}
            <script src=\"{{ asset('js/main.js') }}\"></script>
        {% endblock %}
    </body>
</html>

</div>", "base.html.twig", "/home/emmanuelma/htdocs/hotel-booking/templates/base.html.twig");
    }
}
