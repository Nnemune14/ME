<?php

class person {
	var $name; 

	function set_name($new_name) {
		$this->name = $new_name;
	}
}
$stephan = new person();
$lucky = new person();

$stephan -> set_name('holla');
$lucky -> set_name('heta');

echo "Stefan's full name: " . $stefan->get_name();





class Name {
    var $name;

    function set_name($new_name){
        $this -> name = $new_name;
    }
    function get_name(){
        return $this->name;
    }
}

<input type="button" value="Say Hi!" onclick="location='test.php'" />
babel for javascript
