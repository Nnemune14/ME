<?php

// src/MiWay/Bundle/ClientBundle/Controller/CandidateChallengeController.php
namespace MiWay\Bundle\ClientBundle\Controller;
namespace App\Controller;


use MiWay\Components\Claim\Task;
use Symfony\Component\Routing\Annotation\Routes;
use App\Form\Type\TaskType;
use App\Entity\Task;
use MiWay\Bundle\CoreBundle\Controller\Controller;
use Nelmio\ApiDocBundle\Tests\Functional\Form\UserType;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\Security\Core\User\User;
use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;
use Symfony\Component\Form\Extension\Core\Type\DateType;
use Symfony\Component\Form\Extension\Core\Type\SubmitType;
use Symfony\Component\Form\Extension\Core\Type\TextType;

class CandidateChallengeController extends Controller
{
    public function candidateChallengeAction(Request $request) {
//        dd($request);
//        $user = new CandidateChallengeController();
//        $user->setFullname('name');

//        $collection = array ('name'=>'foo','surname'=>'bar','email'=>'foo@bar.bar','gender'=>'male','favourite_food'=>'pizza');
//        foreach ($collection as $x => $x_value) {
//            return 'lets '.$x_value;
//        }
//        echo $collection;
//        $cc = new Cc();
//        $user->setCandidateName('Nnemune');
//        $user->setCandidateSurname('Matsenene');
//        $user->setCandidateEmail('me@gmail.com');
//        $user->setCandidateGender('Male/Female');
//        $user->setCandidateFavFood('eat');
//        $form = $this->createForm(UserType::class, $user);
//
//        $form->handleRequest($request);
//        if ($form-> isSubmitted()) {
//            dump($user);
//        }
        // creates a task object and initializes some data for this example
        $task = new Task();
        $task->setTask('Write a blog post');
        $task->setDueDate(new \DateTime('tomorrow'));

        $form = $this->createForm(TaskType::class, $task);
        $form = $this->createFormBuilder($task)
            ->add('task', TextType::class)
            ->add('dueDate', DateType::class)
            ->add('save', SubmitType::class, ['label' => 'Create Task'])
            ->getForm();

        return $this->render('task/new.html.twig', [
            'form' => $form->createView(),
        ]);
    }
//    /**
//     *
//     * @param Request $request
//     * @return \Symfony\Component\HttpFoundation\Response
//     */
//    public function candidateChallengeAction(Request $request)
//    {
//        $user = new User();
//        $user->setFullname('name');
//
//        $cc = new Cc();
//        $cc->setCandidateName('Nnemune');
//        $cc->setCandidateSurname('Matsenene');
//        $cc->setCandidateEmail('me@gmail.com');
//        $cc->setCandidateGender('Male/Female');
//        $cc->setCandidateFavFood('eat');
//        $form = $this->createForm(UserType::class, $user);
//
//        $form->handleRequest($request);
//        if ($form-> isSubmitted()) {
//            dump($user);
//        }
//        return $this->render('default/index.html.twig',[
//            'form' => $form->createView()
//        ]);
//    }

}


,['class'=>"form-control" ,'id'=>"inputName", 'name'=>"name", 'placeholder'=>"Email"]





